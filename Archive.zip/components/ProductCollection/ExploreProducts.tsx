import React from 'react'

function ExploreProducts() {
  return (
    <div>ExploreProducts</div>
  )
}

export default ExploreProducts