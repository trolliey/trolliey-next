import React from 'react'

function Toast() {
  return (
    <div>Toast</div>
  )
}

export default Toast