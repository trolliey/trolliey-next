export const convertAmounts = (value: number) => {
   
}