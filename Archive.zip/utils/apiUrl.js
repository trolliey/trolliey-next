export const apiUrl = `https://trolliey-server.onrender.com`
export const socketUrl = `https://trolliey-server.onrender.com`

// export const apiUrl = `http://localhost:5000`
// export const socketUrl = `http://localhost:5500`